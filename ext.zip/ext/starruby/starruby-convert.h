/*
  StarRuby Convert
  vr 0.1.0
  */

#ifndef STARRUBY_CONVERT_H
  #define STARRUBY_CONVERT_H

  #ifndef CBOOL2RUBY
    #define CBOOL2RUBY(_x_) ((_x_) ? Qtrue : Qfalse)
  #endif

#endif
